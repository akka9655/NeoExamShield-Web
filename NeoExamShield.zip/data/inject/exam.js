// Use shared isMac variable if it exists, otherwise declare it
if (typeof window.isMac === 'undefined') {
    window.isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0 || 
                   navigator.userAgent.toUpperCase().indexOf('MAC') >= 0;
}

// Auto-answering and Random Key Press Typing mechanism
(function () {
  try {
    console.log = () => {};
    console.warn = () => {};
    console.error = () => {};
  } catch (e) {}
  let editor;
  let currentCode = "";
  let charIndex = 0;
  let isRandomTypingActive = false;
  let lastQuestionIdentifier = null;

  // Find the answer editor on the page (supports Ace, CodeMirror 6, Monaco, Textarea)
  function findAnswerEditor() {
    const aceObj = (typeof ace !== 'undefined') ? ace : (window.ace || document.defaultView?.ace);

    // Check 1: Explicit answer editor ID, aria label, or container
    const answerEl = document.querySelector('[id*="ttAnswerEditor"], [aria-labelledby="editor-answer"], programming-answer .ace_editor, #programming-editor .ace_editor');
    if (answerEl) {
      if (answerEl.env && answerEl.env.editor) return answerEl.env.editor;
      const childAce = answerEl.querySelector?.('.ace_editor');
      if (childAce?.env?.editor) return childAce.env.editor;
      if (aceObj) {
        try {
          const ed = aceObj.edit(answerEl.id || answerEl);
          if (ed) return ed;
        } catch(e) {}
      }
    }

    // Check 2: First non-readonly ACE editor
    const aceEditors = document.querySelectorAll('.ace_editor, [id*="ttAnswerEditor"]');
    for (const el of aceEditors) {
      try {
        const ed = (el.env && el.env.editor) ? el.env.editor : (aceObj ? aceObj.edit(el.id || el) : null);
        if (ed && typeof ed.setValue === 'function' && !ed.getReadOnly()) return ed;
      } catch(e) {}
    }

    // Check 3: Modern CodeMirror 6 editor (used in new Iamneo / PAT portal UI in new m.md)
    const cmContent = document.querySelector('#programming-editor .cm-content, .cm-editor .cm-content, .cm-content[contenteditable="true"]');
    if (cmContent) {
      const cmEditor = cmContent.closest('.cm-editor') || cmContent;
      return {
        isCodeMirror6: true,
        element: cmContent,
        getReadOnly: () => cmContent.getAttribute('contenteditable') === 'false',
        setValue: function(code) {
          const view = cmEditor.cmView?.view || cmContent.cmView?.view || cmEditor._view;
          if (view && view.dispatch && view.state) {
            try {
              view.dispatch({
                changes: { from: 0, to: view.state.doc.length, insert: code },
                selection: { anchor: code.length }
              });
              return;
            } catch(e) {}
          }

          // Fallback via DOM selection & execCommand
          try {
            cmContent.focus();
            const sel = window.getSelection();
            const range = document.createRange();
            range.selectNodeContents(cmContent);
            sel.removeAllRanges();
            sel.addRange(range);
            let ok = false;
            try {
              ok = document.execCommand('insertText', false, code);
            } catch(e) {}
            if (!ok) {
              cmContent.textContent = code;
              cmContent.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText', data: code }));
            }
            cmContent.dispatchEvent(new Event('input', { bubbles: true }));
            cmContent.dispatchEvent(new Event('change', { bubbles: true }));
          } catch(e) {}
        },
        clearSelection: function() {
          const sel = window.getSelection();
          if (sel && sel.removeAllRanges) sel.removeAllRanges();
        },
        navigateFileEnd: function() {
          try {
            cmContent.focus();
            const sel = window.getSelection();
            const range = document.createRange();
            range.selectNodeContents(cmContent);
            range.collapse(false);
            sel.removeAllRanges();
            sel.addRange(range);
          } catch(e) {}
        },
        focus: function() {
          try { cmContent.focus(); } catch(e) {}
        },
        insert: function(ch) {
          const view = cmEditor.cmView?.view || cmContent.cmView?.view;
          if (view && view.dispatch && view.state) {
            try {
              const pos = view.state.selection.main.head;
              view.dispatch({
                changes: { from: pos, to: pos, insert: ch },
                selection: { anchor: pos + ch.length }
              });
              return;
            } catch(e) {}
          }
          try {
            document.execCommand('insertText', false, ch);
            cmContent.dispatchEvent(new Event('input', { bubbles: true }));
          } catch(e) {}
        }
      };
    }

    // Check 4: Monaco Editor
    if (window.monaco && window.monaco.editor) {
      try {
        const monacoModels = window.monaco.editor.getModels();
        if (monacoModels && monacoModels.length > 0) {
          const model = monacoModels[monacoModels.length - 1];
          return {
            isMonaco: true,
            model: model,
            getReadOnly: () => false,
            setValue: function(code) { model.setValue(code); },
            clearSelection: function() {},
            navigateFileEnd: function() {},
            focus: function() {
              const el = document.querySelector('.monaco-editor');
              if (el) el.focus();
            },
            insert: function(ch) {
              const val = model.getValue();
              model.setValue(val + ch);
            }
          };
        }
      } catch(e) {}
    }

    return null;
  }

  // Get unique identifier for the currently displayed question
  function getQuestionIdentifier() {
    const qEl = document.querySelector('div[aria-labelledby="question-data"]') ||
                document.querySelector('.rich-text-content, div[class*="rich-text-content"]') ||
                document.querySelector('#content-left content-left testtaking-question') ||
                document.querySelector('.qaas-block-question-title') ||
                document.querySelector('[aria-labelledby="code-constraints"]');
    if (qEl) {
      return (qEl.innerText || qEl.textContent || '').slice(0, 120).trim();
    }
    const qNumEl = document.querySelector('div.t-whitespace-nowrap') || document.querySelector('.question-number') || document.querySelector('[id*="question-nav"]');
    return qNumEl ? (qNumEl.innerText || qNumEl.textContent || '').trim() : null;
  }

  // Stop typing mode and clear current question buffer
  window._neoStopTyping = function() {
    if (isRandomTypingActive || currentCode) {
      isRandomTypingActive = false;
      currentCode = "";
      charIndex = 0;
    }
  };

  // Detect question change and automatically stop typing feature
  function checkForQuestionChange() {
    const currentQ = getQuestionIdentifier();
    if (currentQ && lastQuestionIdentifier && currentQ !== lastQuestionIdentifier) {
      window._neoStopTyping();
    }
    if (currentQ) {
      lastQuestionIdentifier = currentQ;
    }
  }

  setInterval(checkForQuestionChange, 350);

  // Stop typing on question navigation clicks
  document.addEventListener('click', function(e) {
    const navBtn = e.target.closest('button, [aria-labelledby="each-question-card"], .question-card, [id*="next"], [id*="prev"], .tab-btn');
    if (navBtn) {
      setTimeout(function() {
        const currentQ = getQuestionIdentifier();
        if (currentQ && currentQ !== lastQuestionIdentifier) {
          window._neoStopTyping();
          lastQuestionIdentifier = currentQ;
        }
      }, 150);
    }
  }, true);

  // Stop typing on URL or history changes
  window.addEventListener('popstate', window._neoStopTyping);
  window.addEventListener('hashchange', window._neoStopTyping);
  window.addEventListener('neoStopTyping', window._neoStopTyping);

  // Helper to strip AI explanatory comments (e.g. // Read inputs, // Consume newline, etc.)
  function stripCodeComments(code) {
    if (!code) return '';
    const originalLines = code.split('\n');
    const wasOriginallyBlank = originalLines.map(l => l.trim() === '');
    let result = '';
    let i = 0;
    let inString = false;
    let inChar = false;

    while (i < code.length) {
      const ch = code[i];
      const next = i + 1 < code.length ? code[i + 1] : '';

      if (!inChar && (ch === '"') && (i === 0 || code[i - 1] !== '\\')) {
        inString = !inString;
        result += ch;
        i++;
        continue;
      }

      if (!inString && (ch === "'") && (i === 0 || code[i - 1] !== '\\')) {
        inChar = !inChar;
        result += ch;
        i++;
        continue;
      }

      if (!inString && !inChar) {
        if (ch === '/' && next === '/') {
          i += 2;
          while (i < code.length && code[i] !== '\n') {
            i++;
          }
          continue;
        }
        if (ch === '/' && next === '*') {
          i += 2;
          while (i + 1 < code.length && !(code[i] === '*' && code[i + 1] === '/')) {
            i++;
          }
          i += 2;
          continue;
        }
        if (ch === '#') {
          const restOfLine = code.slice(i, i + 30).toLowerCase();
          if (!/^#(?:include|define|pragma|ifndef|ifdef|endif|undef|elif|else)\b/.test(restOfLine)) {
            while (i < code.length && code[i] !== '\n') {
              i++;
            }
            continue;
          }
        }
      }

      result += ch;
      i++;
    }

    const strippedLines = result.split('\n');
    const finalLines = [];
    let prevEmpty = false;

    for (let idx = 0; idx < strippedLines.length; idx++) {
      const line = strippedLines[idx].trimEnd();
      if (line.trim() === '') {
        if (wasOriginallyBlank[idx] && !prevEmpty && finalLines.length > 0) {
          finalLines.push('');
          prevEmpty = true;
        }
      } else {
        finalLines.push(line);
        prevEmpty = false;
      }
    }

    return finalLines.join('\n').trim();
  }

  // Fast Instant code insertion into Ace editor (Alt+T)
  window._neopassStartTyping = function(codeToType) {
    if (!codeToType) return;
    window._neoStopTyping(); // Stop any pending random typing
    const cleanCode = stripCodeComments(codeToType.replace(/\r\n/g, '\n')).trim();
    const found = findAnswerEditor();
    if (found) {
      try {
        editor = found;
        editor.setValue(cleanCode, 1);
        editor.clearSelection();
        editor.navigateFileEnd();
      } catch (error) {}
    }
  };

  // Initialize Random Key Press Typing Mode (Alt+X)
  window._neoExamShieldInitRandomTyping = function(codeToType) {
    if (!codeToType) return;
    currentCode = stripCodeComments(codeToType.replace(/\r\n/g, '\n')).trim();
    charIndex = 0;
    isRandomTypingActive = true;
    lastQuestionIdentifier = getQuestionIdentifier();
    editor = findAnswerEditor();
    if (editor) {
      try {
        editor.setValue('', 1);
        editor.clearSelection();
        editor.focus();
        editor.navigateFileEnd();
      } catch(e) {}
    }
  };

  // Keyboard listener for Alt+D / Alt+C (stop) and Random Key Typing
  function handleTypingKeydown(event) {
    // Alt+D / Alt+C: Stop/Off typing mode
    const isAltStop = event.altKey && !event.ctrlKey && !event.shiftKey && !event.metaKey && 
                   (event.code === 'KeyD' || event.code === 'KeyC' || 
                    (event.key && (event.key.toLowerCase() === 'd' || event.key.toLowerCase() === 'c')));
    if (isAltStop) {
      event.preventDefault();
      event.stopPropagation();
      window._neoStopTyping();
      return;
    }

    // Process typing only if mode is active and not holding modifier keys (except Shift)
    if (!isRandomTypingActive || !currentCode) return;
    if (event.ctrlKey || event.metaKey || event.altKey) return;

    // Ignore standalone modifier keys
    const ignoredKeys = ['Shift', 'Control', 'Alt', 'Meta', 'CapsLock', 'Tab', 'Escape'];
    if (ignoredKeys.includes(event.key)) return;

    // Reveal one character from clean solution code on any keypress
    event.preventDefault();
    event.stopPropagation();

    if (charIndex < currentCode.length) {
      charIndex++;
      const partialCode = currentCode.substring(0, charIndex);

      if (!editor) {
        editor = findAnswerEditor();
      }

      if (editor) {
        try {
          editor.setValue(partialCode, 1);
          editor.clearSelection();
          editor.navigateFileEnd();
        } catch(e) {
          try {
            editor.insert(currentCode[charIndex - 1]);
          } catch(err) {}
        }

        if (charIndex >= currentCode.length) {
          isRandomTypingActive = false;
          window.dispatchEvent(new CustomEvent('neoTypingComplete'));
        }
      } else {
        isRandomTypingActive = false;
      }
    }
  }

  window.addEventListener('keydown', handleTypingKeydown, true);
  document.addEventListener('keydown', handleTypingKeydown, true);
})();
